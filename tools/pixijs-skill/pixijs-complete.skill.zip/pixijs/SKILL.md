---
name: pixijs
description: Build, animate, debug, or optimize PixiJS v8 applications. Includes the complete official skill repository as local references, covering 2D scenes, meshes, assets, interaction, rendering, performance, and migration. Use when the project uses PixiJS or the user chooses it.
license: MIT
metadata:
  short-description: Complete PixiJS v8 toolkit in one skill
---

# PixiJS · 全量整合版

One skill entry backed by the complete official `pixijs/pixijs-skills` repository. Read only the topic guides needed for the current task.

## Use the bundle

1. Check the project's installed PixiJS version and existing renderer/loop before choosing an API.
2. Read the matching guide below and follow its linked references. If a guide refers to another `pixijs-*` skill, read that topic's local `GUIDE.md`; it is part of this skill and needs no separate installation.
3. Use the upstream examples and auxiliary guidance only when relevant. Preserve the project's chosen libraries and existing user requirements.
4. For an API absent here or version-dependent details, fetch [the official PixiJS documentation index](https://pixijs.download/release/docs/llms.txt), then the relevant API page. Bundled documents are a pinned snapshot, so resolve conflicts against the installed package and current official docs.

## Topic routing

### Foundations

| Topic guide | Load when... |
|---|---|
| [pixijs-application](upstream/skills/pixijs-application/GUIDE.md) | Creating or configuring a PixiJS `Application`, calling `app.init()`, accessing `app.stage`/`renderer`/`canvas`/`screen`, resize/ticker plugins, `app.destroy()`. |
| [pixijs-core-concepts](upstream/skills/pixijs-core-concepts/GUIDE.md) | Understanding the renderer pipeline, choosing WebGL/WebGPU/Canvas, render loop internals, systems and pipes. |
| [pixijs-create](upstream/skills/pixijs-create/GUIDE.md) | Scaffolding a new project with the `create-pixi` CLI (bundler-vite, creation-web, framework-react templates). |
| [pixijs-environments](upstream/skills/pixijs-environments/GUIDE.md) | Running PixiJS in Web Workers, Node/SSR, or strict-CSP contexts (`DOMAdapter`, `WebWorkerAdapter`, `pixi.js/unsafe-eval`). |
| [pixijs-migration-v8](upstream/skills/pixijs-migration-v8/GUIDE.md) | Upgrading from v7 to v8 or fixing v7 patterns (`beginFill`/`endFill`, `@pixi/*` packages, `BaseTexture`, `DisplayObject`). |
| [pixijs-scene-core-concepts](upstream/skills/pixijs-scene-core-concepts/GUIDE.md) | Understanding the scene graph as a whole: containers vs leaves, transforms, render order, masking, `RenderLayer`. |

### Scene Objects

| Topic guide | Load when... |
|---|---|
| [pixijs-scene-container](upstream/skills/pixijs-scene-container/GUIDE.md) | Working with `Container`: `addChild`/`removeChild`, transforms, `zIndex`, bounds, `toGlobal`/`toLocal`, `destroy`. |
| [pixijs-scene-sprite](upstream/skills/pixijs-scene-sprite/GUIDE.md) | Drawing images: `Sprite`, `AnimatedSprite`, `NineSliceSprite`, `TilingSprite`. |
| [pixijs-scene-graphics](upstream/skills/pixijs-scene-graphics/GUIDE.md) | Drawing vector shapes or paths: `Graphics`, `GraphicsContext`, `fill`/`stroke`, `FillGradient`, SVG. |
| [pixijs-scene-text](upstream/skills/pixijs-scene-text/GUIDE.md) | Rendering text: `Text`, `BitmapText`, `HTMLText`, `SplitText`, `TextStyle`. |
| [pixijs-scene-mesh](upstream/skills/pixijs-scene-mesh/GUIDE.md) | Custom geometry: `Mesh`, `MeshSimple`, `MeshPlane`, `MeshRope`, `PerspectiveMesh`. |
| [pixijs-scene-particle-container](upstream/skills/pixijs-scene-particle-container/GUIDE.md) | Rendering thousands of lightweight sprites: `ParticleContainer`, `Particle`, `dynamicProperties`. |
| [pixijs-scene-dom-container](upstream/skills/pixijs-scene-dom-container/GUIDE.md) | Overlaying HTML elements on the canvas: `DOMContainer`, `pixi.js/dom`. |
| [pixijs-scene-gif](upstream/skills/pixijs-scene-gif/GUIDE.md) | Displaying animated GIFs: `GifSprite`, `GifSource`, `pixi.js/gif`. |
| [pixijs-html-source](upstream/skills/pixijs-html-source/GUIDE.md) | Rendering live HTML/DOM elements or snapshots as textures (experimental, needs a browser that supports the HTML-in-Canvas spec): `HTMLSource`, `ElementImageSource`, `pixi.js/html-source`, `requestPaint`. |

### Utilities

| Topic guide | Load when... |
|---|---|
| [pixijs-assets](upstream/skills/pixijs-assets/GUIDE.md) | Loading resources: `Assets.init`, `Assets.load`, bundles, manifests, spritesheets, caching. |
| [pixijs-color](upstream/skills/pixijs-color/GUIDE.md) | Creating or converting colors: `Color` class, hex/rgb/hsl, `tint`, `premultiply`. |
| [pixijs-events](upstream/skills/pixijs-events/GUIDE.md) | Handling pointer/mouse/touch/wheel input: `eventMode`, `FederatedEvent`, `hitArea`, `cursor`, drag. |
| [pixijs-math](upstream/skills/pixijs-math/GUIDE.md) | Points, vectors, matrices, shapes, hit testing: `Point`, `Matrix`, `Rectangle`, `toGlobal`/`toLocal`. |
| [pixijs-ticker](upstream/skills/pixijs-ticker/GUIDE.md) | Per-frame logic or controlling the render loop: `Ticker`, `deltaTime`, `UPDATE_PRIORITY`, `maxFPS`. |

### Advanced

| Topic guide | Load when... |
|---|---|
| [pixijs-accessibility](upstream/skills/pixijs-accessibility/GUIDE.md) | Screen reader or keyboard navigation: `AccessibilitySystem`, `accessibleTitle`, `tabIndex`. |
| [pixijs-blend-modes](upstream/skills/pixijs-blend-modes/GUIDE.md) | Compositing with blend modes: `add`, `multiply`, `screen`, `overlay`, `pixi.js/advanced-blend-modes`. |
| [pixijs-custom-rendering](upstream/skills/pixijs-custom-rendering/GUIDE.md) | Writing custom shaders, uniforms, or batchers: `Shader.from`, `GlProgram`/`GpuProgram`, `UniformGroup`, custom `Filter`. |
| [pixijs-filters](upstream/skills/pixijs-filters/GUIDE.md) | Applying visual effects: `BlurFilter`, `ColorMatrixFilter`, `DisplacementFilter`, `Filter.from`, `pixi-filters`. |
| [pixijs-performance](upstream/skills/pixijs-performance/GUIDE.md) | Profiling or optimizing FPS, draw calls, GPU memory: culling, `GCSystem`, `cacheAsTexture`, object pooling. |


## Repository content beyond the topic guides

- [Upstream README](upstream/README.md): project overview and original distribution methods.
- [Original router](upstream/skills/pixijs/GUIDE.md) and [full topic index](upstream/skills/pixijs/references/index.md): all original routing descriptions and trigger keywords.
- [Example overview](upstream/examples/README.md), [HTML](upstream/examples/vanilla/index.html), [JavaScript](upstream/examples/vanilla/main.js): a minimal runnable PixiJS example; it uses external CDN resources as documented upstream.
- [React guidance](upstream/.github/instructions/react.instructions.md): when integrating PixiJS with React; verify the installed `@pixi/react` version.
- [Custom rendering guidance](upstream/.github/instructions/scrolltrigger.instructions.md): extra renderer/shader conventions (the upstream filename is retained).
- [Copilot guidance](upstream/.github/copilot-instructions.md): upstream repository-wide conventions, for reference where applicable.
- [Repository authoring rules](upstream/AGENTS.md): relevant when maintaining the upstream skill repository, not a replacement for the target project's instructions. Upstream `CLAUDE.md` is a symlink to that file; its link target is preserved as text in the expanded Windows copy and as a symlink entry in the archive.
- [Claude plugin metadata](upstream/.claude-plugin/plugin.json), [marketplace](upstream/.claude-plugin/marketplace.json), [Cursor plugin metadata](upstream/.cursor-plugin/plugin.json), [marketplace](upstream/.cursor-plugin/marketplace.json): retained for completeness and optional porting, not registered as additional plugins or skills by this bundle.
- [Pixi logo](upstream/assets/pixi-logo.svg), [skills logo](upstream/assets/pixijs-skills-logo.svg), [license](upstream/LICENSE), and upstream `.gitignore` are included.

## Packaging and verification

All upstream tracked files are expanded under `upstream/`. Internal `SKILL.md` files are named `GUIDE.md`, with local links adapted, so only this root file is discoverable as a skill. The original byte-for-byte files and symlink metadata are also retained in [the upstream archive](archive/pixijs-skills-upstream.zip).

See [provenance and file map](references/provenance.md) and `references/upstream-manifest.json`. Run `python scripts/verify_bundle.py` to verify completeness, checksums, the single entrypoint, and local Markdown links. Preserve this structure when updating; do not unpack original `SKILL.md` files into the installed skill folder.
