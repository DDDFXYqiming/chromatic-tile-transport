# Source and local adaptation

Source: https://github.com/pixijs/pixijs-skills

Revision: `6aae70d76cf410432dd144029c07a1ad4bb12793`. Packaged 2026-09-10.

All 81 tracked files are included, including 26 topic entry documents, hidden plugin/Copilot configuration, examples, SVG assets, license and root documentation. The local clone beside the bundle retains the Git history. The installed archive represents the complete file tree at this revision; it does not include Git's local database or network-expanded dependencies.

`upstream-manifest.json` records every original path, Git blob/mode, original SHA-256, expanded path and adapted SHA-256. Expanded Markdown uses `GUIDE.md` for internal topic entrypoints and adapts local links. The archive retains original names and bytes, including symlink metadata. Other source files are unchanged. The upstream README's installation instructions and plugin descriptors describe the original multi-skill distribution; they are retained as reference, not automatically executed.

The single-entry packaging follows [Codex skill structure and progressive disclosure](https://learn.chatgpt.com/docs/build-skills). Only root `SKILL.md` is active; nested guides are on-demand documents.
